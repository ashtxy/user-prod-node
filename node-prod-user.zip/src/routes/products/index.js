const express = require("express");
const router = express.Router();
const ProductController = require("../../controller/products");

router.post("/file_data", async (req, res) => {
    const {data, message, code} = await ProductController.AddFileAndData(req);
    return res.send({code: code, message: message, data: data});
});

router.post("/add", async (req, res) => {
    const {data, message, code} = await ProductController.AddProduct(req);
    return res.send({code: code, message: message, data: data});
});

router.put("/update", async (req, res) => {
    const {data, message, code} = await ProductController.EditProduct(req);
    return res.send({code: code, message: message, data: data});
});

router.delete("/remove/:id", async (req, res) => {
    const {data, message, code} = await ProductController.DeleteProduct(req);
    return res.send({code: code, message: message, data: data});
});

router.get("/list_all", async(req, res) => {
    const {data, message, code} = await ProductController.GetAllProducts(req);
    return res.send({code: code, message: message, data: data});
});

router.get("/list_user_products/:id", async(req, res) => {
    const {data, message, code} = await ProductController.GetUsersProducts(req);
    return res.send({code: code, message: message, data: data});
});

router.get("/details/:id", async(req, res) => {
    const {data, message, code} = await ProductController.GetProductDetails(req);
    return res.send({code: code, message: message, data: data});
});

router.get("/cart", async (req, res) => {
    return res.send({code: 200, message: "Cart route called"});
});

module.exports = router;
