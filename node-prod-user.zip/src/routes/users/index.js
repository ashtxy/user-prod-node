const express = require("express");
const router = express.Router();
const UsersController = require("../../controller/users");

router.post("/login", async (req, res) => {
    const {data, message, code} = await UsersController.Login(req);
    return res.send({code: code, message: message, data: data});
});

router.get("/profile", (req, res) => {
    return res.send({code: 200, message: "Profile route called"});
});

router.get("/orders", (req, res) => {
    return res.send({code: 200, message: "Profile route called"});
});

router.post("/logout", async(req, res) => {
    const {data, message, code} = await UsersController.Logout(req);
    return res.send({code: code, message: message, data: data});
});

module.exports = router;
