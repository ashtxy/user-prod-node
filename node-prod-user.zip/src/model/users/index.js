const mongoose = require("mongoose");
const Users = new mongoose.Schema({
    name: {type: String},
    email: {type: String},
    mobile: {type: String},
    password: {type: String},
    token: {type: String},
    image: {type:String}    
}, {
    timestamps: true
});
const UsersSchema = mongoose.model('users', Users);
module.exports = {
    UsersSchema
}