const mongoose = require("mongoose");
const Products = new mongoose.Schema({
    name: {type: String},
    description: {type: String},
    price: {type: String},
    imageUrl: [{type: String}],
    userId: {type: mongoose.Types.ObjectId}
}, {
    timestamps: true
});
const ProductSchema = mongoose.model('products', Products);
module.exports = {
    ProductSchema
}