const ProductsModel = require("../../model/products").ProductSchema;
const HttpResponse = require("../../../constant/httpResponse");
const ErrorMessage = require("../../../constant/errorMessages.json");
const SuccessMessage = require("../../../constant/successMessages.json");
const _ = require("lodash");
const CommonService = require("../../../services/common");
const FileUploadService = require("../../../services/fileUpload");
const {ObjectId} = require('mongodb');

const AddProduct = async (req) => {
    try {
        if(_.isEmpty(req.body) && _.isEmpty(req.body.userId) && _.isEmpty(req.body.name) && _.isEmpty(req.body.description) && _.isEmpty(req.body.price)){
            return await HttpResponse.errorResponse({message: "Please send proper data"});
        }
        await ProductsModel.create(req.body);
        return await HttpResponse.successResponse({data: {}, message: "AddProduct Success"});
    } catch (error) {
        console.log("AddProduct-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const EditProduct = async (req) => {
    try {
        if(_.isEmpty(req.body) && _.isEmpty(req.body.productId)){
            return await HttpResponse.errorResponse({message: "Please send proper data"});
        }
        const findProd = await ProductsModel.findOne({_id: ObjectId(req.body.productId)});
        if(_.isEmpty(findProd)){
            return await HttpResponse.errorResponse({message: "No Product found"});
        }
        const editObj = {
            name: !_.isEmpty(req.body.name) ? req.body.name : findProd.name,
            description: !_.isEmpty(req.body.description) ? req.body.description : findProd.description,
            price: !_.isEmpty(req.body.price) ? req.body.price : findProd.price,
        }
        await ProductsModel.updateOne({_id: ObjectId(req.body.productId)}, {$set: editObj});
        return await HttpResponse.successResponse({data: {}, message: "EditProduct Success"});
    } catch (error) {
        console.log("EditProduct-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const GetAllProducts = async (req) => {
    try {
        const allProds = await ProductsModel.find({});
        return await HttpResponse.successResponse({data: allProds, message: "Product list fetched successfully"});
    } catch (error) {
        console.log("GetAllProducts-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const GetUsersProducts = async (req) => {
    try {
        if(_.isEmpty(req.params) && _.isEmpty(req.params.id)){
            return await HttpResponse.errorResponse({message: "Please send proper data"});
        }
        const allProds = await ProductsModel.find({userId: ObjectId(req.params.id)});
        return await HttpResponse.successResponse({data: allProds, message: "Product list fetched successfully"});
    } catch (error) {
        console.log("GetAllProducts-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const GetProductDetails = async (req) => {
    try {
        if(_.isEmpty(req.params) && _.isEmpty(req.params.id)){
            return await HttpResponse.errorResponse({message: "Please send proper data"});
        }
        const allProds = await ProductsModel.find({_id: ObjectId(req.params.id)});
        return await HttpResponse.successResponse({data: allProds, message: "Product details fetched successfully"});
    } catch (error) {
        console.log("GetProductDetails-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const DeleteProduct = async (req) => {
    try {
        return await HttpResponse.successResponse({data: {}, message: "DeleteProduct Success"});
    } catch (error) {
        console.log("DeleteProduct-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const AddFileAndData = async (req) => {
    try {
        const parseData = await FileUploadService.parseFormDataRequest(req);
        if(!_.isEmpty(parseData)){
            return await HttpResponse.successResponse({code: 200, data: {}, message: SuccessMessage.PRODUCTS.PRODUCT_ADDED});
        }
        return await HttpResponse.successResponse({code: 201, data: {}, message: ErrorMessage.PRODUCTS.PRODUCT_ADD_ERROR});
    } catch (error) {
        console.log("AddFileAndData-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}


module.exports = {
    AddProduct, EditProduct, 
    GetAllProducts, GetUsersProducts, 
    GetProductDetails, AddFileAndData,
    DeleteProduct
}