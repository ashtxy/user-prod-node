const UsersModel = require("../../model/users").UsersSchema;
const HttpResponse = require("../../../constant/httpResponse");
const ErrorMessage = require("../../../constant/errorMessages.json");
const SuccessMessage = require("../../../constant/successMessages.json");
const _ = require("lodash");
const CommonService = require("../../../services/common");
const {ObjectId} = require('mongodb');

const Login = async (req) => {
    try {
        if(_.isEmpty(req.body)){
            return await HttpResponse.errorResponse({message: "please send data"});
        }
        if(_.isEmpty(req.body.email)){
            return await HttpResponse.errorResponse({message: "Please send email"});
        }
        if(_.isEmpty(req.body.password)){
            return await HttpResponse.errorResponse({message: "Please send password"});
        }
        const token = await CommonService.generateToken(req.body.email);
        await UsersModel.deleteOne({email: req.body.email});
        const userLoginObj = {
            name: "Abc Xyz",
            email: req.body.email,
            password: req.body.password,
            token: token,
        }
        const saveUser = await UsersModel.create(userLoginObj);

        return await HttpResponse.successResponse({data: {
            userId: saveUser._id,
            email: userLoginObj.email,
            token: token
        }, message: "Login Success"});
    } catch (error) {
        console.log("Login-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

const Logout = async () => {
    try {
        if(_.isEmpty(req.body) && _.isEmpty(req.body.userId)){
            return await HttpResponse.errorResponse({message: "please send data"});
        }
        await UsersModel.deleteOne({_id: ObjectId(req.body.userId)});
        return await HttpResponse.successResponse({data: {}, message: "Logout Success"});
    } catch (error) {
        console.log("Logout-error", error);
        return await HttpResponse.errorResponse({message: "Error"});
    }
}

module.exports = {
    Login, Logout
}