const mongoose = require("mongoose");
const Configs = require("../config");
const ErrorMessage = require("../constant/errorMessages.json");
const SuccessMessage = require("../constant/successMessages.json");
mongoose.Promise = global.Promise;
const dbConnect = mongoose.connect(Configs.DB_CONFIG.dbUrl, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }, (error, connected) => {
    if(error){
        console.log(ErrorMessage.MONGO_CONN_ERROR, error);
        throw error;
    }
    console.log(SuccessMessage.MONGO_CONN_CONNECT);
    return;
})
module.exports = {
    dbConnect
}