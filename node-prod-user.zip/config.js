module.exports = {
    PORT: process.env.PORT_DEV,
    DB_CONFIG: {
        dbUrl: process.env.MONGO_DEV
    },
    API_CONFIG: {
        base: process.env.API_BASE,
        version: process.env.API_VERSION 
    },
    TOKEN: {
        privateKey: "Node@123"
    }
}