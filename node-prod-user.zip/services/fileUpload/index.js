const jwt = require("jsonwebtoken");
const Configs = require("../../config");
const FormData = require("form-data");
const path = require("path");
const formidable = require("formidable");
const fs = require("fs");

const sendData = (data) => {
    return data;
}

module.exports = {

    parseFormDataRequest: async (request) => {
        try {
            return new Promise((resolve, reject) => {
                const formInstance = new formidable.IncomingForm();
                const fileUploadDir = path.join(__dirname, "../../public/images");
                formInstance.parse(request, async (err, fields, files) => {
                    if (err) {
                      console.error("Error while parsing req", err.message);
                      return;
                    }
                    const prevFilePath = files.image.filepath;
                    const currentFilePath = fileUploadDir + '/' + files.image.originalFilename;
                    const rawData = fs.readFileSync(prevFilePath);
                    fs.writeFile(currentFilePath, rawData, function(err){
                        if(err) console.log(err)
                        return;
                    })
                    return resolve({files: files, fields: fields});
                });
            });
        } catch (error) {
            console.log("Fun-parseFormDataRequest", error)
            return error;
        }
    },
}