const jwt = require("jsonwebtoken");
const Configs = require("../../config");

module.exports = {
    generateToken: async (payload) => {
        const token = jwt.sign({ email: payload }, Configs.TOKEN.privateKey, {
            algorithm: "HS256",
            expiresIn: 36000,
        });
        return token;
    },
}