module.exports = {
    successResponse: async ({data, message, code}) => {
        return {
            data: data || [],
            message: message || "Success",
            code: code
        }
    },

    errorResponse: async ({message}) => {
        return {
            message: message || "Error",
            code: 404
        }
    }
}