const express = require("express");
const app = express();
require('dotenv').config();
const cors = require("cors");
const ngrok = require('ngrok');
const Configs = require("./config");
(require("./database/connection")).dbConnect;
app.use(express.json());
app.use(express.urlencoded({extended: true, limit: '100mb'}));
app.use(cors({ methods: ["GET", "POST", "PUT", "DELETE"] }));
app.use(express.static(`${__dirname}/public`));

app.use(`${Configs.API_CONFIG.base}/users`, require("./src/routes/users"));
app.use(`${Configs.API_CONFIG.base}/products`, require("./src/routes/products"));

app.listen(Configs.PORT, (err) => {
    if(err){
        return console.log("Error-main-server", error);
    }
    console.log(`Server on ${Configs.PORT}`);
    // ngrok.connect(Configs.PORT, function (err, url) {
    //     console.log(err);
    //     console.log(`Server is publicly-accessible at : ${url}`);
    // });
})